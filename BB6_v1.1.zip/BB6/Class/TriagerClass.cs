﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;

namespace BB6
{
    public class TriagerClass
    {
        private string str1;
        private string str2;
        private string str3;
    }
}